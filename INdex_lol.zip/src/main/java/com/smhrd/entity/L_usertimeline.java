package com.smhrd.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class L_usertimeline {

	private String u_id;
	private int u_timestamp;
	private int u_timegold;
	private int u_timedamage;
	private int u_jmkill;
	private int u_mkill;
	private String u_teamposition;
	private String u_matchcd;
	
	
	
	
	
	
}
